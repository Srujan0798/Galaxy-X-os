# SCALE x ODYSSEY — 6-Slide Presentation
## Google Slides / PowerPoint Ready — 5-Minute Pitch

---

## SLIDE 1: Title + Hook (30 seconds)

**Background**: Deep space image (high-res galaxy photo)
**Layout**: Center-aligned, large typography

```
[Top]    🌌  SCALE × ODYSSEY

[Center] Sequence-Based Classification of 
         Astronomical Objects Using Deep Learning

[Bottom] TechOIITGN Hackathon 2025
         Team: Janil Jain | Jaskirat Singh Maskeen | Priyal Keswani
         
[Tagline] 93% Accuracy | <15ms Inference | Full Explainability
```

**Speaker Notes**: "Good morning judges. We're Team SCALE x ODYSSEY. Every night, telescopes capture millions of astronomical images. Manual classification is the bottleneck. We built a deep learning system that classifies raw telescope images into 5 celestial categories with 93% accuracy and full explainability."

---

## SLIDE 2: The Problem + Our Edge (60 seconds)

**Layout**: Left = Problem, Right = What Makes Us Different

**Left — The Problem**:
- Petabytes of raw telescope images need classification
- Manual annotation by astrophysicists: slow, expensive, unscalable
- Standard ML: basic fine-tuning, generic augmentations, black-box models
- Real observational conditions: cosmic rays, vignetting, sensor noise, varying exposure

**Right — Our Edge**:
| Aspect | Standard Approach | Our Approach |
|--------|-------------------|--------------|
| Training | Naive fine-tuning | Progressive unfreezing + discriminative LR |
| Augmentations | Flip, crop, normalize | 8 astro-specific transforms |
| Explainability | None | 15 Grad-CAM 3-panel visualizations |
| Bonus | None | BLIP captioning + anomaly detection |
| Demo | None | Full Streamlit web app |

**Speaker Notes**: "Most teams will submit a standard fine-tuned model with basic transforms. We went further. Progressive unfreezing preserves pretrained features. Our augmentations simulate real telescope conditions. And every prediction comes with a Grad-CAM heatmap showing exactly why the model decided what it decided."

---

## SLIDE 3: Architecture + Results (90 seconds)

**Layout**: Top = Architecture flowchart, Bottom = Results table

**Architecture Flowchart**:
```
Input (224×224×3)
    ↓
EfficientNet-B3 Backbone [12M params]
    ↓  (frozen 3 epochs → unfrozen with 10× lower LR)
Global Average Pooling
    ↓
BatchNorm → Dropout(0.4) → Linear(1536→512) → ReLU
    ↓
BatchNorm → Dropout(0.2) → Linear(512→256) → ReLU
    ↓
BatchNorm → Dropout(0.1) → Linear(256→5) → Softmax
```

**Results Table**:
| Metric | Standard | With TTA | Target |
|--------|----------|----------|--------|
| Accuracy | **91%** | **93%** | >80% |
| Macro F1 | 0.918 | 0.932 | — |
| Inference | — | **<15ms** | <5s |
| Parameters | — | **12M** | — |

**Per-Class F1 (with TTA)**:
| Spiral Galaxy | Elliptical | Nebula | Star Cluster | Planetary |
|:-:|:-:|:-:|:-:|:-:|
| 0.94 | 0.92 | 0.89 | 0.91 | 0.93 |

**Speaker Notes**: "EfficientNet-B3 gives us the best accuracy-to-parameter ratio. Progressive unfreezing with OneCycleLR and mixed precision training gets us to 91% accuracy. Test-time augmentation with 6 variants pushes us to 93%. Every class scores above 0.85 F1 — no class is left behind."

---

## SLIDE 4: Live Demo (90 seconds)

**Layout**: Large screenshot of Streamlit app + 2 callout boxes

**Main Visual**: Full Streamlit interface showing:
- Uploaded spiral galaxy image (left column)
- Prediction card: "Spiral Galaxy — 94.2%" (right column, top)
- Probability bar chart (right column, middle)
- Grad-CAM overlay (full width below)

**Callout 1** [top-right corner]:
```
Interactive Web Demo
Upload any image → Instant prediction + Grad-CAM
streamlit run app/app.py
```

**Callout 2** [bottom-right corner]:
```
Bonus Features
📝 BLIP Captioning: "A spiral galaxy with..."
⚠️ Anomaly Detection: Flags low-confidence predictions
```

**Speaker Notes**: "This is our Streamlit web demo. Upload any astronomical image and you get the predicted class, confidence score, probability distribution, and a Grad-CAM heatmap showing exactly which regions mattered. The bonus features add automatic captioning and anomaly detection for uncertain predictions."

---

## SLIDE 5: Explainability + Impact (60 seconds)

**Layout**: Left = Grad-CAM grid, Right = Impact text

**Left — Grad-CAM Summary Grid**:
Show 3×5 grid of Grad-CAM overlays (from `results/gradcam/_summary_grid.png`)
- Green borders = correct predictions
- Red borders = misclassifications

**Right — Impact**:

```
Research Impact
✓ Full Grad-CAM explainability for every prediction
✓ 15 diverse 3-panel visualizations generated
✓ Scientists can verify model behavior, catch systematic errors

National Relevance
✓ Extensible to ISRO AstroSat multi-wavelength data
✓ Applicable to Aditya-L1 solar observatory imagery
✓ Step toward data sovereignty in Indian space science

Open Source
✓ Complete codebase: 1,959 lines, 10 modules
✓ 3 Jupyter notebooks for reproducibility
✓ MIT Licensed for research community
```

**Speaker Notes**: "Explainability isn't optional in science. Our Grad-CAM pipeline generates 15 diverse 3-panel visualizations — original, true-class CAM, predicted-class CAM. This is directly extensible to ISRO's AstroSat and Aditya-L1 missions. We're not just building a hackathon project; we're building a tool for Indian space science."

---

## SLIDE 6: Thank You + Q&A (30 seconds)

**Background**: Same deep space image as Slide 1, faded
**Layout**: Center-aligned, minimal

```
🌌  Thank You

SCALE × ODYSSEY
GitHub: [your-repo-link]

Team
  Janil Jain
  Jaskirat Singh Maskeen
  Priyal Keswani

Stakeholders: TechOIITGN

Questions?
```

**Speaker Notes**: "Thank you for your time. Our complete pipeline — code, model, Grad-CAM visualizations, web demo, and documentation — is in the repository. We'd welcome your questions."

---

## Design Specs

| Element | Spec |
|---------|------|
| Background | Dark navy (#0a0a1a) with subtle star field |
| Text | White (#ffffff) for primary, light gray (#94a3b8) for secondary |
| Accent | Space blue (#3b82f6) for highlights, success green (#22c55e) for correct |
| Font | Inter or Roboto (sans-serif) |
| Images | Use actual Grad-CAM outputs from `results/gradcam/` |
| Animations | Simple fade-ins only — no distracting transitions |

## Timing

| Slide | Time | Cumulative |
|-------|------|------------|
| 1 | 0:00-0:30 | 0:30 |
| 2 | 0:30-1:30 | 1:30 |
| 3 | 1:30-3:00 | 3:00 |
| 4 | 3:00-4:30 | 4:30 |
| 5 | 4:30-5:30 | 5:30 |
| 6 | 5:30-6:00 | 6:00 |

**Buffer**: 60 seconds for questions / tech issues.
