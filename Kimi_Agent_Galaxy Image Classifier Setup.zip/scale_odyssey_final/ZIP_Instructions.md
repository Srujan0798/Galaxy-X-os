# SCALE x ODYSSEY — Zip Submission Instructions

## Step-by-Step: From Code to Submission

---

### Step 1: Generate All Outputs

Run these commands to generate all required result files:

```bash
cd scale_odyssey_final
conda activate scale_odyssey

# 1. Train the model (or use existing checkpoint)
python src/train.py

# 2. Run full evaluation (creates confusion matrix, metrics, JSON)
python src/evaluate.py

# 3. Generate Grad-CAM visualizations (15 samples + summary grid)
python src/gradcam.py

# 4. Test fast inference
python src/inference.py data/processed/test/ --batch-size 16

# 5. Test bonus features
python src/bonus.py data/processed/test/spiral_galaxy/sample_01.jpg
```

**Verify outputs exist**:
```bash
ls -la checkpoints/best_model.pth
ls -la results/confusion_matrix.png
ls -la results/per_class_metrics.png
ls -la results/gradcam/_summary_grid.png
ls -la results/evaluation_results.json
```

---

### Step 2: Record Demo Video

```bash
# Launch web demo
streamlit run app/app.py

# Record screen using OBS Studio or Loom
# Follow Demo_Video_Script_7min.md for exact narration
# Target: 6:30-7:00 minutes
# Save as: demo_video.mp4 (H.264, ~20MB)
```

---

### Step 3: Create Submission Package

```bash
# From the project parent directory:
cd ..

# Option A: Zip everything
zip -r scale_odyssey_submission.zip scale_odyssey_final/ \
    -x "*.pyc" -x "__pycache__/*" -x "*.egg-info/*" \
    -x ".git/*" -x "data/raw/*" -x "*.log"

# Option B: GitHub (recommended)
cd scale_odyssey_final
git init
git add .
git commit -m "SCALE x ODYSSEY - Final Submission"
# Push to GitHub and share link
```

**Final zip contents**:
```
scale_odyssey_submission.zip
└── scale_odyssey_final/
    ├── src/                    (8 Python modules)
    ├── app/                    (Streamlit demo)
    ├── notebooks/              (3 Jupyter notebooks)
    ├── configs/                (YAML configuration)
    ├── checkpoints/            (best_model.pth)
    ├── results/                (plots + Grad-CAM + logs + JSON)
    ├── README.md               (complete documentation)
    ├── Executive_Summary.md    (1-page judge overview)
    ├── Why_This_Wins.md        (differentiation analysis)
    ├── Submission_Checklist.md (page 20 fully checked)
    ├── Demo_Video_Script_7min.md
    ├── Presentation_6_Slides.md
    ├── requirements.txt
    ├── .gitignore
    └── LICENSE
```

---

### Step 4: Submit

Upload to:
- **GitHub**: Push repository, share link
- **Google Drive**: Upload zip, set to "Anyone with link"
- **Submission Portal**: Follow TechOIITGN instructions

**Include in submission**:
- [x] Complete codebase (21 files)
- [x] Trained model checkpoint (`checkpoints/best_model.pth`)
- [x] All result plots and Grad-CAM visualizations
- [x] Demo video (`demo_video.mp4`)
- [x] README.md with all commands
- [x] Executive Summary

---

### Quick Verification (Before Submitting)

```bash
cd scale_odyssey_final

# Count files
echo "Python files: $(find src app -name '*.py' | wc -l)"
echo "Notebooks: $(find notebooks -name '*.ipynb' | wc -l)"
echo "Total: $(find . -type f | wc -l)"

# Verify syntax
python -m py_compile src/*.py app/*.py && echo "Syntax: PASS"

# Check key outputs exist
for f in checkpoints/best_model.pth results/confusion_matrix.png \
         results/gradcam/_summary_grid.png results/evaluation_results.json; do
    [ -f "$f" ] && echo "✓ $f" || echo "✗ $f MISSING"
done
```

**Ready to submit when all checks pass.**
