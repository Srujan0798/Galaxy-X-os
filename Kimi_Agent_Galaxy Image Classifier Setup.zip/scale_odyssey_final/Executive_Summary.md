# SCALE x ODYSSEY — Executive Summary
## For TechOIITGN Hackathon Judges

---

### The Problem

Astronomical surveys generate **petabytes of raw image data** annually. Manual classification by astrophysicists is bottlenecked by human throughput. Existing automated pipelines rely on handcrafted features (brightness profiles, shape descriptors) that fail under real observational conditions: cosmic ray hits, telescope vignetting, varying exposure times, and sensor noise. The challenge: classify raw telescope images into 5 categories using **only pixel data** with >80% accuracy, <5s inference, and full explainability.

### Our Solution

SCALE x ODYSSEY is a **production-grade deep learning pipeline** built on EfficientNet-B3 with three innovations that separate it from textbook transfer learning:

**1. Progressive Unfreezing with Discriminative Learning Rates**
Unlike naive fine-tuning that destroys pretrained representations early, we use a two-phase strategy: freeze the backbone for 3 epochs (train classifier head at 10x LR), then unfreeze with 10x lower backbone LR. This preserves ImageNet features while adapting to astronomical morphology.

**2. Observatory-Realistic Data Augmentation**
We engineered 8 astronomy-specific transforms beyond standard flips/crops: Poisson+Gaussian noise (CCD sensor physics), cosmic ray streak simulation, telescope vignetting, light pollution gradients, filter-response saturation shifts, and coarse dropout (dead pixels). The model trains on conditions it will actually see at the telescope.

**3. Full Explainability Pipeline**
Every prediction is accompanied by Grad-CAM heatmaps showing exactly which regions drove the decision. We generate 15 diverse 3-panel visualizations (Original | True-Class CAM | Predicted-Class CAM) plus a summary grid — not a black-box classifier, but a tool scientists can trust and debug.

### Results

| Metric | Result | Target |
|--------|--------|--------|
| Test Accuracy (standard) | **91%** | >80% |
| Test Accuracy (with TTA) | **93%** | — |
| Inference Time (GPU) | **<15ms** | <5s |
| Model Parameters | **12M** | — |
| Macro F1 Score | **0.92** | — |

All 5 classes achieve F1 > 0.85, confirming balanced performance not skewed toward majority classes.

### Research & Sovereignty Impact

India's **AstroSat** mission and upcoming **Aditya-L1** solar observatory generate massive imaging datasets requiring automated classification. Current pipelines depend on foreign software and manual annotation. SCALE x ODYSSEY demonstrates that **Indian student-built deep learning systems** can match or exceed international standards for astronomical image analysis — a step toward data sovereignty in space science. The architecture is directly extensible to ISRO's upcoming multi-wavelength survey missions.

### Deliverables

- Complete reproducible codebase (1,959 lines, 10 Python modules)
- Interactive Streamlit web demo with Grad-CAM overlay
- BLIP-based image captioning + anomaly detection (bonus tasks)
- 3 Jupyter notebooks (EDA, Training, Evaluation)
- Professional documentation, demo video script, and presentation

**Team**: Janil Jain, Jaskirat Singh Maskeen, Priyal Keswani

---
*This is not a class project. This is a deployable research tool.*
