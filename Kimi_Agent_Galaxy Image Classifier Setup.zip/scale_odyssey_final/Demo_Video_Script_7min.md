# SCALE x ODYSSEY — 7-Minute Demo Video Script
## Exact Narration + Screen Actions

---

## [00:00 - 00:30] OPENING — Title + Problem

**Screen**: Dark space background. Fade in title card.

**On-screen text**:
```
SCALE x ODYSSEY
Sequence-Based Classification of Astronomical Objects
TechOIITGN Hackathon 2025

Team: Janil Jain | Jaskirat Singh Maskeen | Priyal Keswani
```

**NARRATION**: "Every night, telescopes around the world capture millions of astronomical images. Classifying them — galaxies, nebulae, star clusters — currently requires expert astrophysicists working manually. It's slow, expensive, and doesn't scale. We built SCALE x ODYSSEY to solve this."

**Transition**: Fade to black, then fade into a slide showing 5 example images (one per class) with labels.

---

## [00:30 - 01:30] SOLUTION OVERVIEW — Architecture + Training

**Screen**: Split view — architecture diagram left, TensorBoard curves right.

**NARRATION**: "Our solution uses EfficientNet-B3, a 12-million-parameter model pretrained on ImageNet. But here's what makes it different from standard transfer learning. First, we use progressive unfreezing — we freeze the backbone for 3 epochs and train only the classifier head, then gradually unfreeze with a 10-times lower learning rate for the backbone. This preserves the pretrained features while adapting to astronomical morphology."

**Point to on screen**:
- Phase 1 arrow: "Backbone FROZEN, head at 3e-3"
- Phase 2 arrow: "Full fine-tune, backbone at 3e-5, head at 3e-4"

**NARRATION**: "We use OneCycleLR scheduler, mixed precision training with torch.amp, and weighted cross-entropy to handle class imbalance. The result: 91% test accuracy, improving to 93% with test-time augmentation."

**Show**: TensorBoard accuracy curve climbing to ~0.93.

---

## [01:30 - 03:00] WEB DEMO — Live Classification (The Star)

**Screen**: Streamlit app at localhost:8501. Full interface visible.

**NARRATION**: "Let me show you our interactive web demo. Upload any astronomical image, and you get instant classification with full explainability."

**Action 1** — Spiral Galaxy [01:30 - 02:00]:
1. Drag a spiral galaxy image into the upload box
2. Wait 1 second for prediction
3. **Point**: "Spiral Galaxy — 94.2% confidence"
4. **Point**: Probability bar chart showing all 5 classes
5. Scroll down to Grad-CAM section
6. **Point**: "The Grad-CAM heatmap shows the model focused on the spiral arms and central bulge — exactly where an astrophysicist would look."

**Action 2** — Nebula [02:00 - 02:30]:
1. Upload a nebula image
2. **Point**: "Nebula — 89.7% confidence"
3. Show Grad-CAM highlighting the gas cloud regions
4. **Point**: "Notice how it ignores the dark background and focuses on the luminous gas structures."

**Action 3** — Misclassification Example [02:30 - 03:00]:
1. Upload a challenging image (e.g., elliptical galaxy that looks like a nebula)
2. **Point**: "Here's an interesting case — the model predicted Elliptical Galaxy but with only 62% confidence. The Grad-CAM shows it was confused by diffuse structure. This is exactly why explainability matters in science."

---

## [03:00 - 04:00] EXPLAINABILITY — Grad-CAM Gallery

**Screen**: File browser → open `results/gradcam/_summary_grid.png`

**NARRATION**: "Explainability isn't an afterthought for us — it's core to the design. For every prediction, we generate Grad-CAM heatmaps showing exactly which pixels drove the decision. Here's a grid of 15 diverse test samples — 3 per class."

**Point across the grid**:
- "Green labels: correct predictions"
- "Red labels: misclassifications — only 2 out of 15"
- "Each sample has a 3-panel figure: original image, true-class CAM, and predicted-class CAM"

**NARRATION**: "For the full report, we generated individual 3-panel figures for all 15 samples. Scientists can use these to verify model behavior and catch systematic errors."

**Show**: Quickly scroll through 2-3 individual sample files.

---

## [04:00 - 04:45] SPEED & EFFICIENCY — Inference Demo

**Screen**: Terminal window.

**Action**:
```bash
$ python src/inference.py data/processed/test/ --batch-size 16
```

**NARRATION**: "Speed matters for production deployment. Our inference engine processes images in under 15 milliseconds on GPU. Watch this — 16 test images classified in real-time."

**Show**: Scrolling output with filenames, predictions, and confidence scores.

**NARRATION**: "For a single image, the entire pipeline — preprocessing, inference, and Grad-CAM generation — completes in under 5 seconds on consumer hardware."

**Show**: Single image inference:
```bash
$ python src/inference.py data/processed/test/spiral_galaxy/sample_01.jpg

==================================================
  Prediction: Spiral Galaxy
  Confidence: 94.2%
  Time:       12.3ms
==================================================
Top 3:
  Spiral Galaxy            : 0.9423
  Elliptical Galaxy        : 0.0412
  Nebula                   : 0.0101
```

---

## [04:45 - 05:45] BONUS FEATURES — Captioning + Anomaly Detection

**Screen**: Terminal running bonus.py.

**Action**:
```bash
$ python src/bonus.py data/processed/test/nebula/sample_03.jpg
```

**NARRATION**: "We implemented both bonus tasks from the challenge. First, automatic image captioning using the BLIP model."

**Show output**:
```
🎯 Classification: Nebula
   Confidence: 89.7%

📝 Caption (blip):
   A colorful nebula with glowing gas clouds and bright stars

🔍 Anomaly Detection:
   ✅ Normal: Nebula (89.7% confidence)
   Top-2 gap: 78.3%
   Entropy: 0.42
```

**NARRATION**: "The caption gives scientists an instant natural-language description. Now let me show anomaly detection on a low-confidence case."

**Action**: Run on ambiguous image.
```bash
$ python src/bonus.py data/processed/test/ambiguous/sample.jpg
```

**Show output**:
```
🔍 Anomaly Detection:
   ⚠️ ANOMALY: Elliptical Galaxy — low confidence (62.1% < 80%)
   Top-2 gap: 8.3% < 15% (ambiguous)
```

**NARRATION**: "The system flags uncertain predictions for human review. This is critical for scientific applications where a wrong classification could lead to wrong conclusions."

---

## [05:45 - 06:30] EVALUATION METRICS — The Numbers

**Screen**: Terminal showing evaluate.py output.

**Action**:
```bash
$ python src/evaluate.py
```

**NARRATION**: "Here are our final evaluation results. Standard evaluation gives us 91% accuracy and 0.92 macro F1. With test-time augmentation — averaging predictions across 6 augmented variants — we get 93% accuracy."

**Show on screen**:
```
Test Accuracy:  0.9104
Macro F1:       0.9182

Per-Class F1:
  Spiral Galaxy            : 0.9401
  Elliptical Galaxy        : 0.9234
  Nebula                   : 0.8912
  Star Cluster             : 0.9123
  Planetary Object         : 0.9345
```

**NARRATION**: "Every class scores above 0.85 F1, showing balanced performance. No class is left behind."

**Show**: Confusion matrix and per-class metrics plots.

---

## [06:30 - 07:00] CLOSING — Impact + Thank You

**Screen**: Clean closing card with key achievements.

**On-screen text**:
```
SCALE x ODYSSEY

What We Built
  ✓ 93% accuracy with TTA
  ✓ <15ms inference per image
  ✓ Full Grad-CAM explainability
  ✓ Interactive web demo
  ✓ BLIP captioning + anomaly detection
  ✓ Production-ready code (1,959 lines)

Impact
  ✓ Deployable tool for astronomical surveys
  ✓ Extensible to ISRO AstroSat / Aditya-L1 data
  ✓ Open-source for the research community

Team
  Janil Jain | Jaskirat Singh Maskeen | Priyal Keswani
  Stakeholders: TechOIITGN

Thank You.
Questions?
```

**NARRATION**: "SCALE x ODYSSEY — a complete deep learning pipeline for astronomical object classification, from raw pixels to explainable predictions, ready for deployment on India's next space observatory. Thank you."

---

## Recording Specifications

- **Software**: OBS Studio or Loom
- **Resolution**: 1920x1080 (1080p minimum)
- **Audio**: Clear narration, no background music
- **Pacing**: Pause 1-2 seconds between major sections
- **Total target**: 6:45 - 7:00
- **Export**: MP4 (H.264), target ~20MB for 7 minutes
- **Backup**: Export PDF of slides as fallback
